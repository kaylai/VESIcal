# VESIcal
A generalized python library for calculating and plotting various things related to mixed volatile (H2O-CO2) solubility in silicate melts.
