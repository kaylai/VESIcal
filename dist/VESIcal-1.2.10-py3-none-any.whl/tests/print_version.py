import VESIcal as v
print("Now testing VESIcal version " + str(v.__version__))